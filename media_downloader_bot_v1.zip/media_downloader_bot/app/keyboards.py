from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def main_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📥 Скачать видео", callback_data="download"),
         InlineKeyboardButton(text="🎵 Извлечь аудио", callback_data="audio")],
        [InlineKeyboardButton(text="🪄 Обработка медиа", callback_data="tools"),
         InlineKeyboardButton(text="🤖 ИИ-помощник", callback_data="ai")],
        [InlineKeyboardButton(text="ℹ️ Помощь", callback_data="help")],
    ])

def back_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⬅️ Главное меню", callback_data="home")]
    ])
