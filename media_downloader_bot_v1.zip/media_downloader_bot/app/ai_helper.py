from openai import AsyncOpenAI

async def ask_ai(api_key: str | None, model: str, prompt: str) -> str:
    if not api_key:
        return "ИИ пока не подключён. Добавь OPENAI_API_KEY в переменные окружения хостинга."
    client = AsyncOpenAI(api_key=api_key)
    response = await client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": "Ты дружелюбный помощник Telegram-бота для обработки медиа. Отвечай по-русски, кратко и понятно."},
            {"role": "user", "content": prompt[:4000]},
        ],
        max_tokens=500,
    )
    return response.choices[0].message.content or "Не удалось получить ответ."
