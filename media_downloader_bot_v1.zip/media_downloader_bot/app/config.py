import os
from dataclasses import dataclass

@dataclass
class Config:
    bot_token: str
    openai_api_key: str | None
    openai_model: str
    max_file_mb: int
    webhook_url: str | None
    webhook_secret: str | None
    port: int

def load_config() -> Config:
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token:
        raise RuntimeError("BOT_TOKEN is missing. Add it to hosting environment variables.")
    return Config(
        bot_token=token,
        openai_api_key=os.getenv("OPENAI_API_KEY") or None,
        openai_model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
        max_file_mb=int(os.getenv("MAX_FILE_MB", "45")),
        webhook_url=os.getenv("WEBHOOK_URL") or None,
        webhook_secret=os.getenv("WEBHOOK_SECRET") or None,
        port=int(os.getenv("PORT", "8080")),
    )
