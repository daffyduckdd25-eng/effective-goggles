import asyncio
import logging
import os
import tempfile
from pathlib import Path

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage

from app.config import load_config
from app.keyboards import main_menu, back_menu
from app.media import validate_url, download_media, cleanup
from app.ai_helper import ask_ai

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)
cfg = load_config()
bot = Bot(token=cfg.bot_token)
dp = Dispatcher(storage=MemoryStorage())

class Flow(StatesGroup):
    waiting_video_url = State()
    waiting_audio_url = State()
    waiting_ai_prompt = State()

def welcome_text():
    return (
        "🎬 <b>MEDIA DOWNLOADER</b>\\n\\n"
        "Привет! Отправь ссылку на видео или выбери функцию ниже.\\n"
        "Источники: YouTube, TikTok и Instagram (доступность зависит от платформы)."
    )

@dp.message(CommandStart())
async def start(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(welcome_text(), reply_markup=main_menu(), parse_mode="HTML")

@dp.message(Command("help"))
async def help_command(message: Message):
    await message.answer(
        "Нажми «Скачать видео» или «Извлечь аудио», затем отправь публичную ссылку.\\n"
        "Используй бот только для материалов, которые вправе сохранять. "
        "Бот не обходит приватность, платный доступ или DRM.",
        reply_markup=back_menu()
    )

@dp.callback_query(F.data == "home")
async def home(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.answer(welcome_text(), reply_markup=main_menu(), parse_mode="HTML")
    await call.answer()

@dp.callback_query(F.data == "download")
async def choose_video(call: CallbackQuery, state: FSMContext):
    await state.set_state(Flow.waiting_video_url)
    await call.message.answer("📥 Пришли ссылку на видео, которое разрешено скачивать.", reply_markup=back_menu())
    await call.answer()

@dp.callback_query(F.data == "audio")
async def choose_audio(call: CallbackQuery, state: FSMContext):
    await state.set_state(Flow.waiting_audio_url)
    await call.message.answer("🎵 Пришли ссылку на видео, из которого можно извлечь аудио.", reply_markup=back_menu())
    await call.answer()

@dp.callback_query(F.data == "tools")
async def tools_info(call: CallbackQuery):
    await call.message.answer("🪄 Доступны MP3-извлечение и получение видео в MP4. Дополнительные инструменты добавим позже.", reply_markup=back_menu())
    await call.answer()

@dp.callback_query(F.data == "ai")
async def ai_start(call: CallbackQuery, state: FSMContext):
    await state.set_state(Flow.waiting_ai_prompt)
    await call.message.answer("🤖 Напиши вопрос или попроси придумать описание к ролику.", reply_markup=back_menu())
    await call.answer()

@dp.callback_query(F.data == "help")
async def help_button(call: CallbackQuery):
    await call.message.answer("Отправь ссылку через меню. Приватные публикации и материалы с ограничениями доступа не поддерживаются.", reply_markup=back_menu())
    await call.answer()

async def process_download(message: Message, state: FSMContext, audio: bool):
    url = (message.text or "").strip()
    if not validate_url(url):
        await message.answer("Не распознал ссылку. Поддерживаются YouTube, TikTok и Instagram.")
        return
    status = await message.answer("⏳ Проверяю ссылку и обрабатываю файл…")
    folder = tempfile.mkdtemp(prefix="media_")
    path = None
    try:
        path, title = await download_media(url, folder, audio, cfg.max_file_mb)
        upload = FSInputFile(path, filename=Path(path).name)
        caption = ("🎵 " if audio else "🎬 ") + title[:700]
        if audio:
            await message.answer_audio(upload, caption=caption[:1000])
        else:
            await message.answer_video(upload, caption=caption[:1000], supports_streaming=True)
        await status.edit_text("✅ Готово!")
    except Exception as exc:
        log.exception("Media processing failed")
        reason = str(exc).replace("<", "").replace(">", "")[:300]
        await status.edit_text("Не удалось получить файл. Платформа могла ограничить доступ, ссылка может быть недоступна или формат не поддерживается.\\n\\nПричина: " + reason)
    finally:
        if path:
            cleanup(path)
        try:
            for item in Path(folder).glob("*"):
                item.unlink(missing_ok=True)
            Path(folder).rmdir()
        except OSError:
            pass
        await state.clear()

@dp.message(Flow.waiting_video_url)
async def video_url(message: Message, state: FSMContext):
    await process_download(message, state, audio=False)

@dp.message(Flow.waiting_audio_url)
async def audio_url(message: Message, state: FSMContext):
    await process_download(message, state, audio=True)

@dp.message(Flow.waiting_ai_prompt)
async def ai_prompt(message: Message, state: FSMContext):
    answer = await ask_ai(cfg.openai_api_key, cfg.openai_model, message.text or "")
    await message.answer(answer, reply_markup=back_menu())
    await state.clear()

@dp.message(F.text)
async def catch_text(message: Message):
    if validate_url(message.text or ""):
        await message.answer("Получил ссылку. Выбери функцию в меню:", reply_markup=main_menu())
    else:
        await message.answer("Выбери функцию в меню или отправь ссылку после нажатия кнопки.", reply_markup=main_menu())

async def main():
    if cfg.webhook_url:
        from aiohttp import web
        from aiogram.webhook.aiohttp_server import SimpleRequestHandler, setup_application
        app = web.Application()
        webhook_path = f"/telegram/{cfg.webhook_secret}" if cfg.webhook_secret else "/telegram/webhook"
        SimpleRequestHandler(dispatcher=dp, bot=bot).register(app, path=webhook_path)
        setup_application(app, dp, bot=bot)
        await bot.set_webhook(cfg.webhook_url.rstrip("/") + webhook_path)
        app.router.add_get("/", lambda request: web.Response(text="Media Downloader Bot is running"))
        runner = web.AppRunner(app)
        await runner.setup()
        await web.TCPSite(runner, "0.0.0.0", cfg.port).start()
        await asyncio.Event().wait()
    else:
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
