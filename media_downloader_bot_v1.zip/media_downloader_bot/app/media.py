import asyncio
import os
from pathlib import Path
from urllib.parse import urlparse
import yt_dlp

ALLOWED_HOSTS = {
    "youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be",
    "tiktok.com", "www.tiktok.com", "vm.tiktok.com", "vt.tiktok.com",
    "instagram.com", "www.instagram.com"
}

def validate_url(url: str) -> bool:
    try:
        parsed = urlparse(url.strip())
        host = (parsed.hostname or "").lower()
        return parsed.scheme in {"http", "https"} and any(
            host == domain or host.endswith("." + domain) for domain in ALLOWED_HOSTS
        )
    except Exception:
        return False

def _download(url: str, folder: str, audio: bool):
    os.makedirs(folder, exist_ok=True)
    opts = {
        "outtmpl": os.path.join(folder, "%(id)s.%(ext)s"),
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "restrictfilenames": True,
        "socket_timeout": 25,
        "retries": 1,
        "max_filesize": 45 * 1024 * 1024,
    }
    if audio:
        opts.update({
            "format": "bestaudio/best",
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }],
        })
    else:
        opts.update({
            "format": "best[ext=mp4][height<=720]/best[height<=720]/best",
            "merge_output_format": "mp4",
        })
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        filename = ydl.prepare_filename(info)
        if audio:
            filename = str(Path(filename).with_suffix(".mp3"))
        if not os.path.isfile(filename):
            candidates = sorted(Path(folder).glob("*"), key=lambda p: p.stat().st_mtime, reverse=True)
            if not candidates:
                raise RuntimeError("The platform did not provide a downloadable file.")
            filename = str(candidates[0])
        return filename, info.get("title", "media")

async def download_media(url: str, folder: str, audio: bool, max_mb: int):
    path, title = await asyncio.to_thread(_download, url, folder, audio)
    size_mb = os.path.getsize(path) / (1024 * 1024)
    if size_mb > max_mb:
        os.remove(path)
        raise ValueError(f"File is {size_mb:.1f} MB; limit is {max_mb} MB.")
    return path, title

def cleanup(path: str):
    try:
        if path and os.path.isfile(path):
            os.remove(path)
    except OSError:
        pass
